package com.example.databaseconn2;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiInterface {
    @GET("register.php")
    Call<User>performRegistration(@Query("username") String username, @Query("password") String password, @Query("dive_num") String dive_num,
                                  @Query("first_name") String first_name, @Query("last_name") String last_name, @Query("company") String company);


    @GET("login.php")
    Call<User>performUserLogin(@Query("username") String username, @Query("password") String password);

}
