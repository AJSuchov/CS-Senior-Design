package com.example.databaseconn2;


import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.http.Query;


/**
 * A simple {@link Fragment} subclass.
 */
public class RegistrationFragment extends Fragment {
    private EditText Username, Password, DiveNum, FirstName, LastName, Company;
    private Button RegInfo;


    public RegistrationFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_registration, container, false);
        Username = view.findViewById(R.id.username);
        Password = view.findViewById(R.id.password);
        DiveNum = view.findViewById(R.id.diveNum);
        FirstName = view.findViewById(R.id.firstName);
        LastName = view.findViewById(R.id.lastName);
        Company = view.findViewById(R.id.company);
        RegInfo = view.findViewById(R.id.regInfo);

        RegInfo.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                performRegistration();
            }
        });

        return view;

    }

    public void performRegistration(){
        String username= Username.getText().toString();
        String password= Password.getText().toString();
        String diveNum= DiveNum.getText().toString();
        String firstName= FirstName.getText().toString();
        String lastName= LastName.getText().toString();
        String company= Company.getText().toString();

        Call<User> call = MainActivity.apiInterface.performRegistration(username,password,diveNum,firstName,
                lastName,company);

        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if (response.body().getResponse().equals("ok")){
                    MainActivity.prefConfig.displayToast("Registration Success!");
                }else if (response.body().getResponse().equals("exists")){
                    MainActivity.prefConfig.displayToast("User Already Exists");
                }else if (response.body().getResponse().equals("error")){
                    MainActivity.prefConfig.displayToast("Something Went Wrong");
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
        Username.setText("");
        Password.setText("");
        DiveNum.setText("");
        FirstName.setText("");
        LastName.setText("");
        Company.setText("");
    }

}
